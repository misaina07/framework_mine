upload de fichier c est a dire du client vers le serveur
pour les donnees simples on a fait binding
maintenant COMMENT faire pour les cas des fichiers:
    Dans employercontroller: methode save
Pour gérer l'upload de fichiers du client vers le serveur dans un contexte Spring Boot, vous pouvez suivre les étapes suivantes :

Creer une classe MapFILE:

    trois field present:
    nom_du_fichier
    type_fichier
    tableau bites

    ensuite instancer du cote framework: rectoCIN type File


    du cote controller Regarder si il y a type MapFILE 

